// Buscador funcional simulado
document.getElementById('buscador').addEventListener('input', function() {
  let filtro = this.value.toLowerCase();
  const tablas = ['tabla-cuadernos','tabla-papel','tabla-arte'];

  tablas.forEach(id => {
    let tabla = document.getElementById(id);
    Array.from(tabla.rows).forEach((row, index) => {
      if(index === 0) return; // encabezado
      row.style.display = Array.from(row.cells).some(cell => 
        cell.textContent.toLowerCase().includes(filtro)
      ) ? '' : 'none';
    });
  });
});
